package sample.model;

import java.sql.Time;
import java.sql.Timestamp;

public class Task {
    private int userId;
    private String task;
    private int taskId;
    private Timestamp dateModified;
    private String description;
    private String urgency;

    public Task() {
    }

    public Task(String task, Timestamp dateModified, String description, String urgency) {
        this.setTask(task);
        this.setDateModified(dateModified);
        this.setDescription(description);
        this.setUrgency(urgency);
    }

    public String getTask() {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }

    public Timestamp getDateModified() {
        return dateModified;
    }

    public void setDateModified(Timestamp dateModified) {
        this.dateModified = dateModified;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUrgency() {
        return urgency;
    }

    public void setUrgency(String urgency) {
        this.urgency = urgency;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getTaskId() {
        return taskId;
    }

    public void setTaskId(int taskId) {
        this.taskId = taskId;
    }
}
