package sample.Databases;

public class Config {
    // Only made few changes here depending on your SQL's description.
    protected String dbHost = "localhost";
    protected String dbPort = "3306";
    protected String dbUser = "root";
    protected String dbPass = "password";
    protected String dbName = "task";
}
