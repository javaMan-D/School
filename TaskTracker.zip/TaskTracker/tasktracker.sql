CREATE SCHEMA `task` ;
CREATE TABLE `task`.`users` (
  `userid` INT NOT NULL AUTO_INCREMENT,
  `firstname` VARCHAR(45) NOT NULL,
  `lastname` VARCHAR(45) NOT NULL,
  `username` VARCHAR(45) NOT NULL,
  `password` VARCHAR(45) NOT NULL,
  `gender` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`userid`));
CREATE TABLE `task`.`tasks` (
  `tasksid` INT NOT NULL AUTO_INCREMENT,
  `userid` INT NOT NULL,
  `task` VARCHAR(225) NOT NULL,
  `datemodified` DATETIME NOT NULL,
  `description` VARCHAR(225) NOT NULL,
  `urgency` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`tasksid`));
ALTER TABLE `tasktracker`.`tasks` 
ADD CONSTRAINT `userid`
  FOREIGN KEY (`userid`)
  REFERENCES `tasktracker`.`users` (`userid`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

